require 'spec_helper'
abort('Refusing to run specs from a production environment') if ENV['RAILS_ENV'] == 'production'
ENV['RAILS_ENV'] = 'test'
require_relative '../config/environment'
abort('Tests cannot run in production') if Rails.env.production?
require 'rspec/rails'

Rails.root.glob('spec/support/**/*.rb').each { |file| require file }

ActiveRecord::Migration.maintain_test_schema!

RSpec.configure do |config|
  config.include BillingHelpers
  config.include ActiveSupport::Testing::TimeHelpers
  config.use_transactional_fixtures = true
  config.infer_spec_type_from_file_location!
  config.filter_rails_from_backtrace!
end
